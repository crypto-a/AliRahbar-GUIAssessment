/*****************************************
 /*Program Name: main
 /*Programmer Name: Ali Rahbar
 /*Program Date: January 20, 2023
 /*Program Description: This program runs the code
 /*Inputs: Run
 /*Outputs: None
 ******************************************/
import Runner.Run;


public class Main
{
    public static void main(String[] args)
    {
        //Call The Run Object to run program
        new Run();
    }
}