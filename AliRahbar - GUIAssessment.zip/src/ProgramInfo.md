#### Program Name: Main
#### Programmer Name: Ali Rahbar
#### Program Date: January 20, 2023
#### Program Description: This program runs the code
#### Inputs: Run Object
#### Outputs: None

---

### IPO Chart:


| **Method Name** | **Inputs**                         | **Outputs**      | **Processes**            |
|-----------------|------------------------------------|------------------|--------------------------|
| main            | None                               | None             | Creates a new Run Object |

### PseudoCode:

```text
Import required files

Create class main
{
    In the main method
    {
        create a new run object
    }
}
```

### Screenshot of results:
![img.png](resultScreenShot.png)

